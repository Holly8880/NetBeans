/*
 * This class builds different types of SQL statement.
 * An object of this class will be able execute delete, add
 * and print database methods.
 * If any of the SQL statements fail a printible exception will be thrown.
 */


package javamysqltest;
import com.mysql.jdbc.Driver;
import java.sql.*;


public class Sqlstatement {
    private Statement statement;
    public Sqlstatement() throws SQLException{
        makeStatement();
    }
    public Statement makeStatement() throws SQLException{
        //Create a connection to the database ready to execute statements
        Connect c = new Connect();
        Connection conn = c.makeConnection();
        statement = conn.createStatement();
        return statement;
    }
    
    //private String prepareData(String title, String forename, String surname, String address, String postcode, String DOB, String gender, String membership_type, String subscription, String memberID){
        // add single quotes around VARCHAR fields
        //String[] fieldArray = rawdata.split(",");
        //String preparedString=
        //"'"+fieldArray[0]+"','"+fieldArray[1]+"','"+fieldArray[2]+"','"+fieldArray[3]+"','"+fieldArray[4]+"','"+fieldArray[5]+"','"+fieldArray[6]+"','"+fieldArray[7]+"','"+fieldArray[7]+"','"+fieldArray[8]+"','"+fieldArray[9]+"'"; //3 for first name, surname and student ID
        //System.out.println(preparedString+" here");
        //return preparedString;
    //}
     
    public void insertData(String title, String forename, String surname, String address, String postcode, String DOB, String gender, String membership_type, String subscription)throws SQLException{
        //String preparedData=prepareData(title, forename, surname, address, postcode, DOB, gender, membership_type, subscription, memberID);  
        statement.execute("INSERT INTO members(Title, Firstname, Surname, Address, Postcode, DOB, Gender, MembershipType, MembershipSubs) VALUES('"+title+"','"+forename+"','"+surname+"','"+address+"','"+postcode+"','"+DOB+"','"+gender+"','"+membership_type+"','"+subscription+"')"); //incorporates SQL
    //(Title, Forename, Surname, Address, Postcode, DateOfBirth, Gender, MembershipType, Subscription, MemberID) 
    }
    
    public void updateData(String value, String id, String field) throws SQLException
    {
        //String currentData = "Billy";
        //String changingData = "Sally";
        statement.execute("UPDATE gymmembership.members SET "+field+"= '"+value+"' WHERE MemberID="+id); //changes a data field depending on the memberID
        //String updateSQL = ("UPDATE member SET firstname = 'Bob' WHERE firstname ='Sally'");
        //System.out.println("Updating...");
        //statement.execute(updateSQL);
        //viewTable();
    }
    public void deleteAllData()throws SQLException{     
        statement.execute("DELETE FROM members"); //SQL again 
    }
    
    public void selectAll() throws SQLException
    {
       statement.execute("SELECT * FROM gymmembership.members");
    }
    
    public void viewTable() throws SQLException {
   
 String info = "";
        //MemberDisplay newView = new MemberDisplay(info);
        String query;
          query = "select * from gymmembership.members";
        String Title = "";
        String Forename = "";
        String Surname = "";
        String Address = "";
        String Postcode = "";
        String DateOfBirth = "";
        String Gender = "";
        String MembershipType = "";
        String Subscription = "";
        String MemberID = "";
        //int count = 1;
        
        try {       
             ResultSet rs = statement.executeQuery(query);
                while (rs.next()) {
                    Title = rs.getString("Title");
                    Forename = rs.getString("Firstname");
                    Surname = rs.getString("Surname");
                    Address = rs.getString("Address");
                    Postcode = rs.getString("Postcode");
                    DateOfBirth = rs.getString("DOB");
                    Gender = rs.getString("Gender");
                    MembershipType = rs.getString("MembershipType");
                    Subscription = rs.getString("MembershipSubs");
                    MemberID = rs.getString("MemberID");
                    info = (Title+ "\t" +Forename+ "\t" +Surname+ "\t" +Address+ "\t" +Postcode+ "\t" +DateOfBirth+ "\t" +Gender+ "\t" +MembershipType+ "\t" +Subscription+ "\t" +MemberID);
                    System.out.println(info);
                    //newView.AddLine(info);
                    //new MemberDisplay(info);
                 //String[] data = new String[10];
                 //data[count] = info;
                 //count ++;
                }
        } catch (SQLException e ) {
        //JDBCTutorialUtilities.printSQLException(e);
        } finally {
                if (statement != null) { statement.close(); }
        }
        //return info;
        //return info;
    }
}
