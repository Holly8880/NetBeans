/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package screenshots;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author p_smithho
 */
public class SQLstatements {
    private Statement statement;
    public SQLstatements() throws SQLException{
        makeStatement();
    }
    public Statement makeStatement() throws SQLException{
        //Create a connection to the database ready to execute statements
        Connect c = new Connect();
        Connection conn = c.makeConnection();
        statement = conn.createStatement();
        return statement;
    }
    /*
    I have taken this code from a previous project which reads in a csv file listing data on cats to be used for a cattery
        try {
            //System.out.println("trying to read from csv");
            AQAReadTextFile rFile = new AQAReadTextFile("N:\\NetBeansProjects\\LVI Cattery DB\\Design drawer\\src\\my\\numberaddition\\CatteryCats.csv"); //finds csv file
            AQAConsole console= new AQAConsole();
            Sqlstatement s = new Sqlstatement();
            s.deleteCatData();
            String currentLine = rFile.readLine();
            do {
                if (currentLine!=null){
                    s.insertCatData (currentLine);
                }
                currentLine = rFile.readLine();
            }while (currentLine!=null);
            System.out.println("Success");
        }
        catch(SQLException e){
            System.out.println("Failed" + e);
        }
        */
    public void insertCSV(String filePath)
    {
        int count = 0;
        AQAReadTextFile rFile = new AQAReadTextFile(filePath); //finds csv file
        AQAConsole console = new AQAConsole();
        String currentLine = rFile.readLine();
        do
        {
            if ((currentLine!=null)&&(count==0))
            {
                initialiseSubjects(currentLine);
            }
            else if (currentLine!=null)
            {
                insertResultData(currentLine);
            }
            count++;
            currentLine = rFile.readLine();
        }
        while (currentLine!=null);
        System.out.println("Success");
    }
    public void initialiseSubjects(String currentLine)
    {
        String[] topRow = currentLine.split(",");
        String[] subject_code = new String[topRow.length-3]; //cuts out the headers for number and names
        for (int i=0; i<(topRow.length-3);i++)
        {
            subject_code[i] = topRow[i+3];
            System.out.println(subject_code[i]);
            String currentCode = subject_code[i];
            try
            {
                insertSubjectData(currentCode);
            }
            catch (SQLException e)
            {
                System.out.println("Failed" + e);
            }
            
            
        }

    }
    /*
    public void insertCatData(String newData)throws SQLException{
        String preparedData=prepareData(newData);  
        statement.execute("insert into cats values("+preparedData+")"); //incorporates SQL
        System.out.println("insertCatData");
    }
    */
    public void insertSubjectData(String code) throws SQLException
    {
        statement.execute("INSERT INTO subjects(code) VALUES('"+code+"');");
        System.out.println(code+" read in.");
    }
    public void insertCandidateData()
    {
        
    }
    public void insertResultData(String currentLine)
    {
        //String preparedData = prepareData(currentLine);
        
    }
    /*
    private String prepareData(String rawdata){
        // add single quotes around VARCHAR fields
        String[] fieldArray = rawdata.split(",");
        String preparedString=
             "'"+fieldArray[0]+"','"+fieldArray[1]+"','"+fieldArray[2]+"','"+fieldArray[3]+"'"; //3 for first name, surname and student ID
        System.out.println(preparedString+" here");
        return preparedString;
    }
    */
    public void prepareData (String newData)
    {
        String[] fieldArray = newData.split(",");
    }
}
