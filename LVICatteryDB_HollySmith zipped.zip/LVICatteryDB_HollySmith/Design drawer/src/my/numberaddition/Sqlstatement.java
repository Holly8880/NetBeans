/*
 * This class builds different types of SQL statement.
 * An object of this class will be able execute delete, add
 * and print database methods.
 * If any of the SQL statements fail a printible exception will be thrown.
 */


package my.numberaddition;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import com.mysql.jdbc.Driver;
import java.sql.*;


public class Sqlstatement {
    private Statement statement;
    public Sqlstatement() throws SQLException{
        makeStatement();
    }
    public Statement makeStatement() throws SQLException{
        //Create a connection to the database ready to execute statements
        Connect c = new Connect();
        Connection conn = c.makeConnection();
        statement = conn.createStatement();
        return statement;
    }
    
    private String prepareData(String rawdata){
        // add single quotes around VARCHAR fields
        String[] fieldArray = rawdata.split(",");
        String preparedString=
             "'"+fieldArray[0]+"','"+fieldArray[1]+"','"+fieldArray[2]+"','"+fieldArray[3]+"'"; //3 for first name, surname and student ID
        System.out.println(preparedString+" here");
        return preparedString;
    }
     
    public void insertCatData(String newData)throws SQLException{
        String preparedData=prepareData(newData);  
        statement.execute("insert into cats values("+preparedData+")"); //incorporates SQL
        System.out.println("insertCatData");
    }
    public void addCatData(String cat_name, String notes, String owner_id) throws SQLException
    {
        statement.execute("insert into cats(cat_name, notes, owner_ID) values ('"+cat_name+"','"+notes+"','"+owner_id+"')"); //incorporates SQL
        System.out.println("addCatData");
    }
    public void insertOwnerData(String newData)throws SQLException{
        String preparedData=prepareData(newData);  
        statement.execute("insert into owners values("+preparedData+")"); //incorporates SQL
        System.out.println("insertOwnerData");
    }
    public void addOwnerData(String title, String forename, String surname) throws SQLException
    {
        statement.execute("insert into owners(title, forename, surname) values ('"+title+"','"+forename+"','"+surname+"')"); //incorporates SQL
        System.out.println("addOwnerData");
    }
    public void insertHolidayData(String newData)throws SQLException{
        String preparedData=prepareData(newData);  
        statement.execute("insert into holidays values("+preparedData+")"); //incorporates SQL
        System.out.println("insertHolidayData");
    }
    public void addHolidayData(String cat_code, String date_in, String cage_no, String no_nights) throws SQLException
    {
        statement.execute("insert into holidays values ('"+cat_code+"','"+date_in+"','"+cage_no+"','"+no_nights+"')"); //incorporates SQL
        System.out.println("addHolidayData");
    }
    public void editCatData(String cat_code, String notes) throws SQLException
    {
        String updateSQL = ("UPDATE cats SET notes = '"+notes+"' WHERE cat_code = '"+cat_code+"'");
        System.out.println("Updating...");
        statement.execute(updateSQL);
        //viewTable();
    }
    
    public void deleteCatData()throws SQLException{     
        statement.execute("DELETE FROM cats"); //SQL again
    }
    public void deleteOwnerData()throws SQLException{     
        statement.execute("DELETE FROM owners"); //SQL again
    }
    public void deleteHolidayData()throws SQLException{     
        statement.execute("DELETE FROM holidays"); //SQL again
    }
    
    public void cancelHolidayData(String cat_code, String date_in) throws SQLException
    {
        statement.execute("DELETE FROM holidays WHERE cat_code = '"+cat_code+"' AND date_in = '"+date_in+"'");
    }
    public String[] viewBookings(String date_in, String date_out) throws SQLException
    {
        //String query = ("SELECT cat_code, date_in, cage_no, no_nights FROM holidays WHERE date_in>='"+date_in+"' AND date_in<='"+date_out+"'");
        String query = ("SELECT cat_code, date_in, cage_no, no_nights FROM holidays WHERE date_in BETWEEN '"+date_in+"' AND '"+date_out+"'");
        //select Date,TotalAllowance from Calculation where EmployeeId=1 and Date between 2011/02/25 and 2011/02/27
        String cat_code = " ";
        String date = " ";
        String cage_no = " ";
        String no_nights = " ";
        String[] info = new String[1000];
        int count = 0;
        try
        {
            ResultSet rs = statement.executeQuery(query);
            while (rs.next())
            {
                cat_code = rs.getString("cat_code");
                date = rs.getString("date_in");
                cage_no = rs.getString("cage_no");
                no_nights = rs.getString("no_nights");
                info[count] = cat_code+", "+date+", "+cage_no+", "+no_nights;
                System.out.println("Bookings: "+info[count]);
                count++;
            }
        }
        catch (SQLException e)
        {
            System.out.println("View failure."+e);
        }
        finally
        {
            if (statement!=null)
            {
                statement.close();
            }
        }
        return info;
    }
    
    public String viewOwnerID(String title, String forename, String surname) throws SQLException
    {
        String query = ("SELECT owner_ID FROM owners WHERE title='"+title+"' AND forename='"+forename+"' AND surname='"+surname+"'");
        String owner_id = "";
        try
        {
            ResultSet rs = statement.executeQuery(query);
            while (rs.next())
            {
                owner_id = rs.getString("owner_ID");
            }
        }
        catch (SQLException e)
        {
            System.out.println("Failure.");
        }
        finally
        {
            if (statement!=null)
            {
                statement.close();
            }
        }
        return owner_id;
        //SELECT owner_ID FROM Owners
        //WHERE title='Mrs'AND forename='Tess'AND surname='Smith';
    }
    public void viewBusiestMonth() throws SQLException
    {
        String query;
        query = "SELECT date_in FROM holidays"; //I know that I need to put something in here involving datepart, but I haven't figured it out yet...
    }
    public void viewTable() throws SQLException {
   
        String query;
          query = "select * from school.student";
          
        try {       
             ResultSet rs = statement.executeQuery(query);
                while (rs.next()) {
                    String studFirstName = rs.getString("firstname");
                    String studSurname = rs.getString("lastname");
                    int studID = rs.getInt("student ID");
                    System.out.println
                       (studFirstName + "\t" + studSurname + "\t"+studID);
                }
        } catch (SQLException e ) {
        //JDBCTutorialUtilities.printSQLException(e);
        } finally {
                if (statement != null) { statement.close(); }
        }
    }
    public String[] viewOwnerBookings(String owner_ID) throws SQLException
    {
        String query = ("SELECT date_in, no_nights, cage_no, cats.cat_code FROM holidays, cats WHERE cats.owner_ID = '"+owner_ID+"' AND holidays.cat_code = cats.cat_code");
        //SELECT date_in, no_nights, cage_no FROM cats, holidays WHERE cats.owner_ID = 1 AND holidays.cat_code = cats.cat_code;
        String cat_code = " ";
        String date_in = " ";
        String cage_no = "";
        String no_nights = " ";
        String[] info = new String[1000];
        int count = 0;
        try
        {
            ResultSet rs = statement.executeQuery(query);
            while (rs.next())
            {
                cat_code = rs.getString("cat_code");
                date_in = rs.getString("date_in");
                cage_no = rs.getString("cage_no");
                no_nights = rs.getString("no_nights");
                info[count] = cat_code+", "+date_in+", "+cage_no+", "+no_nights;
                System.out.println("Bookings: "+info);
                count++;
            }
        }
        catch (SQLException e)
        {
            System.out.println("View failure."+e);
        }
        finally
        {
            if (statement!=null)
            {
                statement.close();
            }
        }
        return info;
    }
    public void backup() throws SQLException
    {
        //statement.execute("SELECT cat_code, date_in, cage_no, no_nights INTO OUTFILE 'N:\\NetBeansProjects\\LVI Cattery DB\\Design drawer\\src\\my\\numberaddition\\CatteyHols.csv' FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"'LINES TERMINATED BY '\\n'\n" "FROM kate_cattery.holidays);
    //I think this may have been a bit ambitious when I started this...
    }/*
     * SELECT cat_code, date_in, cage_no, no_nights INTO OUTFILE 'N:\NetBeansProjects\LVI Cattery DB\Design drawer\src\my\numberaddition\CatteyHols.csv'
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
FROM kate_cattery.holidays;
     */
    public int busiestMonth() throws SQLException
    {
        int count = 0;
        int current_count = 0;
        int month = 1;
        String query = "";
        for (int i=1; i<=12; i++)
        {
            try
            {
                query = ("SELECT COUNT(cat_code)AS MonthCount FROM holidays WHERE date_in BETWEEN '2016-"+i+"-01' AND '2016-"+i+"-31'");
                ResultSet rs = statement.executeQuery(query);
                while(rs.next())
                {
                //System.out.println(rs);
                current_count = rs.getInt("MonthCount");
                System.out.println(current_count);
                if (current_count>count)
                {
                    count=current_count;
                    month = i;
                    //System.out.println(month);
                }
                System.out.println("Success in busiestMonth");
                }
            }
            catch (SQLException e)
            {
                System.out.println("View failure."+e);
            }
        }
        //System.out.println(month);
        return month;
    }
}
