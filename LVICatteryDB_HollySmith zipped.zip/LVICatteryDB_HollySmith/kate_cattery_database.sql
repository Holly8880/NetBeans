-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 24, 2016 at 12:14 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kate_cattery`
--
CREATE DATABASE IF NOT EXISTS `kate_cattery` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `kate_cattery`;

-- --------------------------------------------------------

--
-- Table structure for table `cats`
--

CREATE TABLE IF NOT EXISTS `cats` (
  `cat_code` int(25) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(256) NOT NULL,
  `notes` varchar(1024) NOT NULL,
  `owner_ID` int(25) NOT NULL,
  PRIMARY KEY (`cat_code`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `cats`
--

INSERT INTO `cats` (`cat_code`, `cat_name`, `notes`, `owner_ID`) VALUES
(1, 'Princess', 'Will scratch and bite', 1),
(2, 'Toby', 'Cut back the snacks!', 2),
(3, 'Joe', 'Bit of a fighter', 1),
(4, 'Katty', 'Very shy', 2),
(5, 'Tiger', 'Needs cuddles', 4),
(6, 'Brain', 'Special Diet', 3),
(7, 'Tilly', 'Escape artist', 5),
(8, 'Jasper', 'Handle with care', 6),
(9, 'Tigger', 'Special Diet', 10),
(10, 'Lucy', 'Very shy', 9),
(11, 'Bob', 'Cut back the snacks!', 7),
(12, 'Harry', 'Needs cuddles', 7),
(13, 'Suki', 'Special Diet', 7),
(14, 'Tigger', 'Escape artist', 8),
(15, 'Tom', 'Special Diet', 8),
(16, 'Pooky', 'Needs cuddles', 12),
(17, 'Mr Tibbles', 'Escape artist', 11),
(18, 'Garfield', 'Special Diet', 11),
(19, 'Sammy', 'Very shy', 14),
(20, 'Lulu', 'Escape artist', 15),
(21, 'Snowball', 'Cut back the snacks!', 13),
(22, 'Tabby', 'Special Diet', 13),
(23, 'Whiskers', 'Special Diet', 16);

-- --------------------------------------------------------

--
-- Table structure for table `holidays`
--

CREATE TABLE IF NOT EXISTS `holidays` (
  `cat_code` int(25) NOT NULL,
  `date_in` date NOT NULL,
  `cage_no` int(2) NOT NULL,
  `no_nights` int(2) NOT NULL,
  PRIMARY KEY (`cat_code`,`date_in`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `holidays`
--

INSERT INTO `holidays` (`cat_code`, `date_in`, `cage_no`, `no_nights`) VALUES
(1, '2016-04-08', 2, 6),
(1, '2016-06-01', 2, 3),
(1, '2016-06-02', 6, 2),
(1, '2016-06-12', 2, 6),
(1, '2016-06-23', 3, 6),
(2, '2000-04-04', 1, 1),
(2, '2016-06-23', 5, 10),
(2, '2016-06-26', 4, 2),
(2, '2016-08-19', 1, 8),
(2, '2016-12-12', 2, 14),
(2, '2017-03-11', 3, 6),
(3, '2016-04-08', 1, 6),
(3, '2016-06-02', 5, 2),
(3, '2016-06-12', 1, 6),
(3, '2016-06-23', 2, 6),
(4, '2016-06-23', 6, 10),
(4, '2016-08-19', 2, 8),
(4, '2016-12-12', 3, 14),
(4, '2017-03-11', 4, 6),
(5, '2016-06-01', 3, 7),
(5, '2016-08-24', 6, 10),
(6, '2016-06-02', 4, 5),
(6, '2016-08-21', 7, 12),
(7, '2016-05-24', 1, 3),
(7, '2016-08-23', 9, 5),
(8, '2016-06-22', 6, 9),
(9, '2016-05-30', 8, 10),
(10, '2016-05-29', 10, 5),
(10, '2016-08-22', 10, 4),
(11, '2016-06-02', 9, 12),
(12, '2016-05-05', 2, 7),
(13, '2016-05-06', 1, 8),
(14, '2016-07-11', 4, 7),
(14, '2016-08-20', 3, 2),
(15, '2016-07-09', 5, 11),
(16, '2016-06-19', 7, 6),
(17, '2016-05-20', 2, 8),
(18, '2016-09-20', 4, 3),
(19, '2016-09-22', 5, 12),
(20, '2016-07-18', 1, 9),
(21, '2016-07-17', 2, 12),
(22, '2016-05-12', 3, 2),
(23, '2016-06-11', 3, 6),
(23, '2016-09-12', 1, 7),
(23, '2016-12-01', 2, 9);

-- --------------------------------------------------------

--
-- Table structure for table `owners`
--

CREATE TABLE IF NOT EXISTS `owners` (
  `owner_ID` int(25) NOT NULL AUTO_INCREMENT,
  `title` varchar(26) NOT NULL,
  `forename` varchar(26) NOT NULL,
  `surname` varchar(26) NOT NULL,
  PRIMARY KEY (`owner_ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `owners`
--

INSERT INTO `owners` (`owner_ID`, `title`, `forename`, `surname`) VALUES
(1, 'Mrs', 'Tess', 'Smith'),
(2, 'Mr', 'Richard', 'Collins'),
(3, 'Mrs', 'Gillian', 'Gilbert'),
(4, 'Mr', 'George', 'Peters'),
(5, 'Ms', 'Chloe', 'Taylor'),
(6, 'Mrs', 'Fiona', 'Smyth'),
(7, 'Mr', 'Jim', 'Barnes'),
(8, 'Ms', 'Poppy', 'Jones'),
(9, 'Mrs', 'Jill', 'Sneak'),
(10, 'Mr', 'Bill', 'Walters'),
(11, 'Mr', 'Phil', 'Jones'),
(12, 'Ms', 'Sam', 'Lovat'),
(13, 'Mrs', 'Katy', 'Tweed'),
(14, 'Mrs', 'Jessica', 'Black'),
(15, 'Mr', 'Joe', 'Brown'),
(16, 'Mrs', 'Lilli', 'Pang');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
