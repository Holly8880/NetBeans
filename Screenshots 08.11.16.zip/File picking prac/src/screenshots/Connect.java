/*
 * This class sets up a database connection object.
 * If there is a problem connecting to the specified database an exception
 * will be thrown. Printing this from where you create an object of this
 * class will help you find out the issue.
 */
package screenshots;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import com.mysql.jdbc.Driver;
import java.sql.*;

public class Connect {
    public Connect() throws SQLException{
        makeConnection();
    } 

    private Connection dbConnection;  

     public  Connection makeConnection() throws SQLException {
        if (dbConnection == null) {
             new Driver();
            
             dbConnection = DriverManager.getConnection(
                       "jdbc:mysql://localhost/exams", //open up wamp server, try to find a school database and login
                       "root",
                       "");
         }
         return dbConnection;
     }  
}